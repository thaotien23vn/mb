import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  Image,
  TouchableOpacity,
  SafeAreaView,
  ActivityIndicator,
  ScrollView,
} from 'react-native';
import { useSelector, useDispatch } from 'react-redux';
import AntDesign from '@expo/vector-icons/AntDesign';
import Feather from '@expo/vector-icons/Feather';
import { useFonts } from 'expo-font';
import {
  fetchBikes,
  setSelectedCategory,
  deleteBike,
  updateBike,
} from '../store/bikesSlice';
import AddBikeModal from './AddBikeModal';
import EditBikeModal from './EditBikeModal';
import BikeDetails from './BikeDetails';

const BikeShop = ({ navigation }) => {
  const [isModalAddBikeVisible, setIsModalAddBikeVisible] = useState(false);
  const [isModalEditBikeVisible, setIsModalEditBikeVisible] = useState(false);
  const dispatch = useDispatch();
  const [bikeToEdit, setBikeToEdit] = useState(null);
  const { items, status, error, selectedCategory } = useSelector(
    (state) => state.bikes
  );

  const [fontsLoaded] = useFonts({
    Ubuntu: require('../assets/fonts/Ubuntu-Regular.ttf'),
    'Ubuntu-Bold': require('../assets/fonts/Ubuntu-Bold.ttf'),
    'Voltaire-Regular': require('../assets/fonts/Voltaire-Regular.ttf'),
  });

  useEffect(() => {
    if (status === 'idle') {
      dispatch(fetchBikes());
    }
  }, [status, dispatch]);

  const filteredBikes =
    selectedCategory === 'All'
      ? items
      : items.filter((bike) => bike.category === selectedCategory);

  if (!fontsLoaded) {
    return null;
  }

  if (status === 'loading') {
    <View style={styles.loadingContainer}>
      <ActivityIndicator size="small" color="#0000ff" />
      <Text>Loading Donuts</Text>
    </View>;
  }

  if (status === 'failed') {
    return <Text>Error: {error}</Text>;
  }

  const handleEditBike = (bike) => {
    setBikeToEdit(bike);
    setIsModalEditBikeVisible(true);
  };

  const handleDeleteBike = (bikeId) => {
    dispatch(deleteBike(bikeId));
  };

  const renderBikeItem = ({ item }) => (
    <TouchableOpacity
      style={styles.bikeItem}
      onPress={() => navigation.navigate('BikeDetails', { id: item.id })}>
      <View style={styles.iconContainer}>
        <TouchableOpacity style={styles.iconButton}>
          <AntDesign
            name="hearto"
            size={24}
            color="black"
            borderColor="black"
          />
        </TouchableOpacity>
        <TouchableOpacity 
          style={styles.iconButton}
          onPress={() => setIsModalEditBikeVisible(true)}
        >
          <Feather name="edit" size={24} color="black" />
        </TouchableOpacity>
      </View>
      <Image
        source={{ uri: item.image }}
        style={styles.bikeImage}
        defaultSource={require('../assets/images/bike-1.png')}
      />
      <Text style={styles.bikeName}>{item.name}</Text>
      <Text style={styles.bikePrice}>
        <Text style={styles.currencySymbol}>$</Text>
        {item.price}
      </Text>
      <TouchableOpacity onPress={() => handleDeleteBike(item.id)}>
        <Text style={styles.deleteBike}>Delete this bike</Text>
      </TouchableOpacity>
    </TouchableOpacity>
  );

  const renderCategoryButton = (category) => (
    <TouchableOpacity
      style={[
        styles.categoryButton,
        selectedCategory === category && styles.selectedCategoryButton,
      ]}
      onPress={() => dispatch(setSelectedCategory(category))}>
      <Text
        style={[
          styles.categoryButtonText,
          selectedCategory === category && styles.selectedCategoryButtonText,
        ]}>
        {category}
      </Text>
    </TouchableOpacity>
  );

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>The world's Best Bike</Text>

      <TouchableOpacity
        style={styles.btnAddNewBike}
        onPress={() => setIsModalAddBikeVisible(true)}>
        <Text style={styles.addNewBikeText}>Add New Bike</Text>
      </TouchableOpacity>

      <View style={styles.categoryContainer}>
        {renderCategoryButton('All')}
        {renderCategoryButton('Roadbike')}
        {renderCategoryButton('Mountain')}
      </View>

      <FlatList
        data={filteredBikes}
        renderItem={renderBikeItem}
        keyExtractor={(item) => item.id}
        numColumns={2}
        columnWrapperStyle={styles.bikeList}
      />

      <AddBikeModal
        visible={isModalAddBikeVisible}
        onClose={() => setIsModalAddBikeVisible(false)}
      />

      <EditBikeModal
        visible={isModalEditBikeVisible}
        onClose={() => {
          setIsModalEditBikeVisible(false);
          setBikeToEdit(null); // Clear the bike to edit after closing
        }}
        bikeData={bikeToEdit}
      />
    </ScrollView>
  );
};

// Styles remain the same as in your original file

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    padding: 15,
    // flexDirection: 'column',
  },
  btnAddNewBike: {
    width: 150,
    height: 40,
    backgroundColor: '#E94141',
    borderRadius: 5,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  addNewBikeText: {
    fontFamily: 'Voltaire-Regular',
    fontSize: 20,
    color: '#FFFFFF',
  },
  title: {
    fontFamily: 'Ubuntu-Bold',
    fontSize: 24,
    lineHeight: 33,
    color: '#E94141',
    marginTop: 20,
    marginBottom: 30,
  },
  categoryContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  categoryButton: {
    width: 100,
    height: 32,
    lineHeight: 32,
    borderWidth: 1,
    borderColor: 'rgba(233, 65, 65, 0.53)',
    borderRadius: 5,
    justifyContent: 'center',
    alignItems: 'center',
    textAlign: 'center',
  },
  selectedCategoryButton: {
    backgroundColor: 'rgba(233, 65, 65, 0.1)',
  },
  categoryButtonText: {
    fontFamily: 'Voltaire-Regular',
    fontSize: 20,
    color: '#BEB6B6',
    textAlign: 'center',
    lineHeight: 22,
  },
  selectedCategoryButtonText: {
    color: '#E94141',
    textAlign: 'center',
  },
  bikeList: {
    justifyContent: 'space-between',
  },
  bikeItem: {
    width: '48%',
    height: 300,
    backgroundColor: 'rgba(247, 186, 131, 0.15)',
    borderRadius: 10,
    marginBottom: 15,
    padding: 10,
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  iconContainer: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    marginBottom: 16,
  },
  iconButton: {
    padding: 8, 
    borderRadius: 20,
    marginHorizontal: 5, 
    backgroundColor: '#f0f0f0',
  },
  bikeImage: {
    width: 120,
    height: 120,
    resizeMode: 'contain',
  },
  bikeName: {
    fontFamily: 'Voltaire-Regular',
    fontSize: 20,
    color: 'rgba(0, 0, 0, 0.6)',
  },
  bikePrice: {
    fontFamily: 'Voltaire-Regular',
    fontSize: 20,
    color: '#000000',
  },
  deleteBike: {
    margin: 5,
    fontFamily: 'Ubuntu',
    fontWeight: '500',
    color: 'red',
  },
  currencySymbol: {
    color: '#F7BA83',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});

export default BikeShop;
