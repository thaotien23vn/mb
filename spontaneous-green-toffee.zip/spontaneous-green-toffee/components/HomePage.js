import React, { useState } from 'react';
import {
  View,
  ScrollView,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useFonts } from 'expo-font';

import BikeList from './BikeList';

const HomePage = ({ navigation }) => {
  // state for name input
  const [name, setName] = useState('');

  // load fonts
  const [fontsLoaded] = useFonts({
    VT323: require('../assets/fonts/VT323-Regular.ttf'),
    Ubuntu: require('../assets/fonts/Ubuntu-Regular.ttf'),
  });

  if (!fontsLoaded) {
    return null;
  }

  return (
    <View style={styles.container}>
      <ScrollView>
        <LinearGradient
          colors={['#F9F7F6', '#F9F7F6']}
          style={styles.background}>
          <Text style={styles.headerLabel}>
            A paragraph online store for sporter and their stylish choice
          </Text>

          <View style={styles.bgImage}>
            <Image
              style={styles.logo}
              source={require('../assets/images/image_home.png')}
            />
          </View>

          <Text style={styles.title}>POWER BIKE {'\n'} SHOP</Text>

          <TouchableOpacity
            style={styles.button}
            onPress={() => navigation.navigate('BikeList')}>
            <Text style={styles.buttonText}>Get Started</Text>
          </TouchableOpacity>
        </LinearGradient>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#000',
    padding: 24,
    overflow: 'hidden',
  },
  background: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingTop: 60,
    paddingBottom: 60,
  },
  headerLabel: {
    margin: 24,
    marginTop: 0,
    fontSize: 26,
    lineHeight: 26,
    fontFamily: 'VT323',
    fontWeight: 'bold',
    textAlign: 'center',
  },
  bgImage: {
    flex: 1,
    width: 300,
    height: 300,
    backgroundColor: 'rgba(233, 65, 65, 0.1)',
    borderRadius: 50,
    alignItems: 'center',
    justifyContent: 'center',
  },
  logo: {
    height: 250,
    width: 250,
    resizeMode: 'contain',
  },
  title: {
    marginTop: 30,
    fontFamily: 'Ubuntu',
    fontWeight: '700',
    fontSize: 26,
    lineHeight: 30,
    textAlign: 'center',
    color: '#000',
  },
  button: {
    width: 250,
    height: 60,
    backgroundColor: '#E94141',
    color: 'white',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 10,
    marginTop: 40,
    borderRadius: 30,
    cursor: 'pointer',
  },
  buttonText: {
    fontFamily: 'VT323',
    fontSize: 27,
    lineHeight: 27,
    color: 'white',
  },
});

export default HomePage;
