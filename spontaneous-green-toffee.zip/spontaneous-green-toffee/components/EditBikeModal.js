import React, { useState, useEffect } from 'react';
import {
  Modal,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
} from 'react-native';
import { useDispatch } from 'react-redux';
import { updateBike } from '../store/bikesSlice';

const EditBikeModal = ({ visible, onClose, bikeData }) => {
  const dispatch = useDispatch();
  const [editedBike, setEditedBike] = useState(null);

  useEffect(() => {
    // Update editedBike whenever bikeData changes
    if (bikeData) {
      setEditedBike({ ...bikeData });
    }
  }, [bikeData]); // Add bikeData to the dependency array

  const handleSubmit = () => {
    // Kiểm tra xem editedBike có tồn tại trước khi gọi API
    if (editedBike) {
      dispatch(updateBike(editedBike));
      onClose(); // Close the modal only after a successful update
    } else {
      console.error('Error: editedBike is null');
    }
  };

  if (!bikeData) {
    // Check if bikeData is available before rendering
    return null;
  }

  return (
    <Modal visible={visible} animationType="slide" transparent>
      <View style={styles.modalContainer}>
        <View style={styles.modalContent}>
          <Text style={styles.modalTitle}>Edit Existing Bike</Text>

          <TextInput
            style={styles.input}
            placeholder="Bike Name"
            value={editedBike ? editedBike.name : ''}
            onChangeText={(text) =>
              setEditedBike({ ...editedBike, name: text })
            }
          />

          <TextInput
            style={styles.input}
            placeholder="Price"
            value={editedBike ? editedBike.price : ''}
            onChangeText={(text) =>
              setEditedBike({ ...editedBike, price: parseFloat(text || '0') })
            }
            keyboardType="numeric"
          />

          <TextInput
            style={styles.input}
            placeholder="Category (Mountain/Roadbike)"
            value={editedBike ? editedBike.category : ''}
            onChangeText={(text) =>
              setEditedBike({ ...editedBike, category: text })
            }
          />

          <TextInput
            style={styles.input}
            placeholder="Image"
            value={editedBike ? editedBike.image : ''}
            onChangeText={(text) =>
              setEditedBike({ ...editedBike, image: text })
            }
          />

          <View style={styles.buttonContainer}>
            <TouchableOpacity
              style={styles.submitButton}
              onPress={handleSubmit}>
              <Text style={styles.buttonText}>Update Bike</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.cancelButton} onPress={onClose}>
              <Text style={styles.buttonText}>Cancel</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    width: '80%',
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 10,
  },
  modalTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    padding: 10,
    marginBottom: 15,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  submitButton: {
    backgroundColor: '#E94141',
    padding: 10,
    borderRadius: 5,
    width: '45%',
  },
  cancelButton: {
    backgroundColor: '#666',
    padding: 10,
    borderRadius: 5,
    width: '45%',
  },
  buttonText: {
    color: 'white',
    textAlign: 'center',
    fontSize: 16,
  },
});

export default EditBikeModal;
