import React, { useEffect } from 'react';
import {
  View,
  Text,
  Image,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import { AntDesign } from '@expo/vector-icons';
import Feather from '@expo/vector-icons/Feather';
import { useFonts } from 'expo-font';
import { useSelector, useDispatch } from 'react-redux';
import { fetchBikes } from '../store/bikesSlice';

const BikeDetails = ({ route, navigation }) => {
  const { id } = route.params; // Get the bike ID from navigation params
  const dispatch = useDispatch();
  const { items, status, error } = useSelector((state) => state.bikes);

  useEffect(() => {
    if (status === 'idle') {
      dispatch(fetchBikes());
    }
  }, [status, dispatch]);

  const bike = items.find((bike) => bike.id === id);

  const [fontsLoaded] = useFonts({
    Voltaire: require('../assets/fonts/Voltaire-Regular.ttf'),
  });

  if (!fontsLoaded) {
    return null;
  }

  if (status === 'loading') {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#E94141" />
      </View>
    );
  }

  if (status === 'failed') {
    return <Text>Error: {error}</Text>;
  }

  if (!bike) {
    return <Text>Bike not found!</Text>; // Handle case where bike is not found
  }

  return (
    <View style={styles.container}>
      <View style={styles.bgItem}>
        <Image
          source={{ uri: bike.image }}
          style={styles.productImage}
          resizeMode="contain"
        />
      </View>
      <Text style={styles.productName}>{bike.name}</Text>
      <View style={styles.priceContainer}>
        <Text style={styles.discountedPrice}>
          {/* Replace with actual discount logic if needed */}
          15% OFF | ${bike.price * 0.85}
        </Text>
        <Text style={styles.originalPrice}>${bike.price}</Text>
      </View>
      <Text style={styles.descriptionTitle}>Description</Text>
      <Text style={styles.descriptionText}>
        {bike.description || 'No description available.'}
      </Text>{' '}
      {/* Handle missing description */}
      <View style={styles.iconContainer}>
        <TouchableOpacity style={styles.iconButton}>
          <AntDesign
            name="hearto"
            size={24}
            color="black"
            borderColor="black"
          />
        </TouchableOpacity>
        <TouchableOpacity style={styles.iconButton}>
          <Feather name="edit" size={24} color="black" />
        </TouchableOpacity>
      </View>
      <View style={styles.buttonContainer}>
        <TouchableOpacity
          style={styles.goBackButton}
          onPress={() => navigation.navigate('BikeList')}>
          <Text style={styles.goBackText}>Go back</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.addToCartButton}>
          <Text style={styles.addToCartText}>Add to cart</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginVertical: 10,
    padding: 16,
    backgroundColor: '#FFF',
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#000',
  },
  bgItem: {
    flex: 1,
    backgroundColor: 'rgba(233, 65, 65, 0.1)',
    borderRadius: 5,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  productImage: {
    width: '100%',
    height: undefined,
    aspectRatio: 1.5,
  },
  productName: {
    fontFamily: 'Voltaire',
    fontSize: 28,
    color: '#000',
    textAlign: 'center',
    marginBottom: 10,
  },
  priceContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  discountedPrice: {
    fontFamily: 'Voltaire',
    fontSize: 20,
    color: 'rgba(0, 0, 0, 0.59)',
  },
  originalPrice: {
    fontFamily: 'Voltaire',
    fontSize: 20,
    textDecorationLine: 'line-through',
    color: '#000',
  },
  descriptionTitle: {
    fontFamily: 'Voltaire',
    fontSize: 18,
    color: '#000',
    marginBottom: 6,
  },
  descriptionText: {
    fontFamily: 'Voltaire',
    fontSize: 16,
    color: 'rgba(0, 0, 0, 0.57)',
    marginBottom: 10,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginTop: 20,
  },
  goBackButton: {
    backgroundColor: '#f0f0f0',
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 20,
    paddingHorizontal: 30,
    paddingVertical: 12,
    flex: 1,
    marginHorizontal: 5,
    alignItems: 'center',
  },
  goBackText: {
    fontFamily: 'Voltaire',
    fontSize: 18,
    color: '#333',
  },
  addToCartButton: {
    backgroundColor: '#E94141',
    borderRadius: 20,
    paddingHorizontal: 30,
    paddingVertical: 12,
    flex: 1,
    marginHorizontal: 5,
    alignItems: 'center',
  },
  addToCartText: {
    fontFamily: 'Voltaire',
    fontSize: 18,
    color: '#FFFAFA',
  },
  iconContainer: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    marginBottom: 16,
  },
  iconButton: {
    padding: 8, 
    borderRadius: 20,
    marginHorizontal: 5, 
    backgroundColor: '#f0f0f0',
  },
});

export default BikeDetails;
