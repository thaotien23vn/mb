import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

const API_URL = 'https://671cb18409103098807ae082.mockapi.io/Redux';

// Async thunk for fetching bikes
export const fetchBikes = createAsyncThunk('bikes/fetchBikes', async () => {
  const response = await axios.get(API_URL);
  return response.data;
});

// Async thunk for adding a new bike
export const addBike = createAsyncThunk('bikes/addBike', async (bikeData) => {
  const response = await axios.post(API_URL, bikeData);
  return response.data;
});

// Async thunk for deleteing a bike
export const deleteBike = createAsyncThunk(
  'bikes/deleteBike',
  async (bikeId) => {
    const response = await axios.delete(`${API_URL}/${bikeId}`);
    return bikeId;
  }
);

// Async thunk for updating a bike
export const updateBike = createAsyncThunk(
  'bikes/updateBike',
  async (bikeData) => {
    const response = await axios.put(`${API_URL}/${bikeData.id}`, bikeData);
    return response.data;
  }
);

const bikesSlice = createSlice({
  name: 'bikes',
  initialState: {
    items: [],
    status: 'idle', // idle | loading | succeeded | failed
    error: null,
    selectedCategory: 'All',
  },
  reducers: {
    setSelectedCategory: (state, action) => {
      state.selectedCategory = action.payload;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchBikes.pending, (state) => {
        state.status = 'loading';
      })
      .addCase(fetchBikes.fulfilled, (state, action) => {
        state.status = 'succeeded';
        state.items = action.payload;
      })
      .addCase(fetchBikes.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.error.message;
      })
      .addCase(addBike.fulfilled, (state, action) => {
        state.items.push(action.payload);
      })
      .addCase(deleteBike.fulfilled, (state, action) => {
        state.items = state.items.filter((bike) => bike.id !== action.payload);
      })
      .addCase(deleteBike.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.error.message;
      })
      .addCase(updateBike.fulfilled, (state, action) => {
        // Update the bike in the state.  Find the bike by ID and replace it.
        const index = state.items.findIndex((bike) => bike.id === action.payload.id);
        if (index !== -1) {
          state.items[index] = action.payload;
        }
      })
      .addCase(updateBike.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.error.message;
      });
  },
});

export const { setSelectedCategory } = bikesSlice.actions;
export default bikesSlice.reducer;
